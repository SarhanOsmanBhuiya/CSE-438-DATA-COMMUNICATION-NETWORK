<?php
//To Handle Session Variables on This Page
session_start();

//Including Database Connection From db.php file to avoid rewriting in all files
require_once("db.php");

//If user clicked register button
if(isset($_POST)) {
	
	//Escape Special Characters In String First
	$name = mysqli_real_escape_string($conn, $_POST['uname']);
	$email = mysqli_real_escape_string($conn, $_POST['email']);
	$password = mysqli_real_escape_string($conn, $_POST['psw']);

	

    //sql query to check if email already exists or not
	$sql = "SELECT Email FROM users WHERE Email='$email'";
	$result = $conn->query($sql);

		//if email not found then we can insert new data
	    if($result->num_rows == 0) {


	       $sql = "INSERT INTO users(uname,Email,Password) values ('$name','$email' , '$password') ";
	      
	                                                                                                  
	          if($conn->query($sql)===True){
	             $_SESSION['registerCompleted'] = true;
		         header("Location: home.php");
		         exit();
	          }else {
		         echo "Error" . $sql . "<br>" . $conn->error;
				 }
	    } else {
		      $_SESSION['registerError'] = true;
			  header("Location: home.php");
			  exit();
		}

		$conn->close();

}else{
	header("Location: home.php");
	exit();
}