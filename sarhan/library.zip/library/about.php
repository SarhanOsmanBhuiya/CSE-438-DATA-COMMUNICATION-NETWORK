<!DOCTYPE html>
<html>
<head>
	<title>LIBRARY MANAGEMENT SYSTEM</title>

	<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

	<link rel="stylesheet" type="text/css" href="style.css">

</head>

<body>

	<div class="container">
		
				<div class="header">
					
					<div class="name">
						<div class="row">
						
								<h1>LIBRARY MANAGEMENT SYSTEM</h1>
							
						</div>
					</div>

					<div class="navbar">
						<!-- Load an icon library -->
						<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

						<div class="navbar">
						  <a href="home.php"><i class="fa fa-fw fa-home"></i> HOME</a> 
						  <a href="books.php"><i class="fa fa-fw fa-book"></i>BOOKS</a> 
						  <a href="about.php"><i class="fa fa-fw fa-user"></i>ABOUT</a>

						  <form class="form-inline search">
						    <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
						    <button class="searchbtn" type="submit"><i class="fa fa-fw fa-search"></i></button>
						  </form>
						</div>
					</div>

				</div>




				



					<div class="row">

						<div class="contact">
							<div class="row">
								<div class="col-md-7 col-md-offset-2">
									<h2>Contact Number : <span>316723,2334678</span></h2>
									<h2>Email : <span>sarhan@gmail.com</span></h2>
									<h2>Facebook : <span>Library Management System</span></h2>
									<h2><span>We Care</span></h2>
								</div>
							</div>
						</div>

						
					</div>
				







				





				<div class="footer">
			<div class="row">

				<div class="col-md-4">
			<div class="footer">
				<h4>ABOUT US</h4>
	            	<p>Laura Pergolizzi (born March 18, 1981) is an American singer and songwriter who performs under the stage name LP. She has released four albums and one EP. .</p>
			</div>
			</div>

			<div class="col-md-4">
				<div class="footer">
					<h4>FOLLOW US</h4>
					<ul>
		                    <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
		                    <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
		                    <li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
		                    <li><a href="#"><i class="fa fa-youtube" aria-hidden="true"></i></a></li>
		            </ul>
					
				</div>
			</div>


			<div class="col-md-4">
				<div class="footer">
					<h4>DOWNLOAD OUR APPS</h4>
		            	<div class="appimg">
		                        <a href="#"> <img src="img/play.jpg"></a>
		                        <a href="#"> <img src="img/ios.jpg"></a>
		            	</div>
				</div>
			</div>


			</div>
				</div>

				<div class="row">
					<div class="end">
				                <p>Sarhan Osman Bhuiya Limited</p>
				        </div>
				     </div>
				</div>

	</div>

</body>
</html>