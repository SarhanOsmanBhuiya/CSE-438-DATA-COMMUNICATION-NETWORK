<?php
session_start();
require_once("db.php");
//If user clicked login button
  if(isset($_POST)) {

	//Escape Special Characters in String
	$uname = mysqli_real_escape_string($conn, $_POST['uname']);
	$password = mysqli_real_escape_string($conn, $_POST['psw']);



	//sql query to check user login
	$sql = "SELECT *  FROM  users WHERE uname='$uname' AND Password='$password'";
	$result = $conn->query($sql);

	//if user table has this this login details
	if($result->num_rows > 0) {
		//output data
		while($row = $result->fetch_assoc()) {

			    $_SESSION['uname'] = $row['uname'];
				$_SESSION['Id'] = $row['Id'];
				header("Location: admin.php");
				exit();
			}

		} else {
			 $_SESSION['loginError'] = true;
			 header("Location: home.php");
			 exit();
		}

		$conn->close();

  } else {
      //redirect them back to login page
  	  header("Location: home.php");
	  exit();
  }
