<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<title>LIBRARY MANAGEMENT SYSTEM</title>

	<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

	<link rel="stylesheet" type="text/css" href="style.css">

</head>

<body>

	<div class="container">

				<div class="header">

					<div class="name">
						<div class="row">

								<h1>LIBRARY MANAGEMENT SYSTEM</h1>

						</div>
					</div>

					<div class="navbar">
						<!-- Load an icon library -->
						<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

						<div class="navbar">
						  <a href="home.php"><i class="fa fa-fw fa-home"></i> HOME</a>
						  <a href="books.php"><i class="fa fa-fw fa-book"></i>BOOKS</a>
						  <a href="about.php"><i class="fa fa-fw fa-user"></i>ABOUT</a>

						  <form class="form-inline search">
						    <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
						    <button class="searchbtn" type="submit"><i class="fa fa-fw fa-search"></i></button>
						  </form>
						</div>
					</div>

				</div>




				<div class="signin">

					<form method="post" action="checklogin.php">
					  <div class="imgcontainer">
					    <img src="img/login.jpg" alt="Avatar" class="avatar">
					  </div>

					  <div class="b container">
					    <label for="uname"><b>Username</b></label>
					    <br>
					    <input class="b" type="text" placeholder="Enter Username" name="uname" required>
					    <br>
					    <label for="psw"><b>Password</b></label>
					    <br>
					    <input class="b" type="password" placeholder="Enter Password" name="psw" required>
					    <br>
					    <button type="submit">Login</button>
					    <br>
					    <label>
					      <input type="checkbox" checked="checked" name="remember"> Remember me
					    </label>
					  </div>
					  <?php
			  if(isset($_SESSION['registerCompleted'])){
			  	  ?>
				  <div>
				  <p class="text-center">You Have Registered Succesfully!</p>
				  </div>
			  <?php
			   unset($_SESSION['registerCompleted']);}
			  ?>
			  <?php
			  if(isset($_SESSION['loginError'])){
			  	  ?>
				  <div>
				  <p class="text-center">Invalid Username/Password! Try Again!</p>
				  </div>
               <?php
			     unset($_SESSION['loginError']);}
			   ?>
              </form>

				</div>


				<div class="signup">

					<form method="post" action="adduser.php"> style="border:1px solid #ccc">
					  <div class="container">
					    <h1>Sign Up</h1>
					    <p>Please fill in this form to create an account.</p>
					    <hr>
                        
						
						<label for="uname"><b>Username</b></label>
					    <br>
					    <input type="text" placeholder="Enter Username" name="uname" required>

					    <br>
						
					
					    <label for="email"><b>Email</b></label>
					    <br>
					    <input type="text" placeholder="Enter Email" name="email" required>

					    <br>

					    <label for="psw"><b>Password</b></label>
					    <br>
					    <input type="password" placeholder="Enter Password" name="psw" required>

					    <br>

					    <label for="psw-repeat"><b>Repeat Password</b></label>
					    <br>
					    <input type="password" placeholder="Repeat Password" name="psw-repeat" required>

					    <br>

					    <label>
					      <input type="checkbox" checked="checked" name="remember" style="margin-bottom:15px"> Remember me
					    </label>

					    <p>By creating an account you agree to our <a href="#" style="color:dodgerblue">Terms & Privacy</a>.</p>

					    <div class="clearfix">
					    	<button type="submit" class="signupbtn">Sign Up</button>

					      <br>

					      	<button type="button" class="cancelbtn">Cancel</button>
					    </div>
					  </div>
					<?php
			  if(isset($_SESSION['registerError'])){
			  	  ?>
				  <div>
				  <p class="text-center">Email Already Exists!</p>
				  </div>
               <?php
			     unset($_SESSION['registerError']);}
			   ?>
            </form>   

				</div>













				<div class="footer">
			<div class="row">

				<div class="col-md-4">
			<div class="footer">
				<h4>ABOUT US</h4>
	            	<p>Laura Pergolizzi (born March 18, 1981) is an American singer and songwriter who performs under the stage name LP. She has released four albums and one EP. .</p>
			</div>
			</div>

			<div class="col-md-4">
				<div class="footer">
					<h4>FOLLOW US</h4>
					<ul>
		                    <li><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
		                    <li><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
		                    <li><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
		                    <li><a href="#"><i class="fa fa-youtube" aria-hidden="true"></i></a></li>
		            </ul>

				</div>
			</div>


			<div class="col-md-4">
				<div class="footer">
					<h4>DOWNLOAD OUR APPS</h4>
		            	<div class="appimg">
		                        <a href="#"> <img src="img/play.jpg"></a>
		                        <a href="#"> <img src="img/ios.jpg"></a>
		            	</div>
				</div>
			</div>


			</div>
				</div>

				<div class="row">
					<div class="end">
				                <p>Sarhan Osman Bhuiya Limited</p>
				        </div>
				     </div>
				</div>

	</div>

</body>
</html>
